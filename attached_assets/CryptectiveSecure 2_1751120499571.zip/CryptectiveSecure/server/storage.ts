import {
  users,
  contactRequests,
  serviceRequests,
  blogPosts,
  cryptoStats,
  type User,
  type InsertUser,
  type ContactRequest,
  type InsertContactRequest,
  type ServiceRequest,
  type InsertServiceRequest,
  type BlogPost,
  type InsertBlogPost,
  type CryptoStats,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Contact request operations
  createContactRequest(request: InsertContactRequest): Promise<ContactRequest>;
  getContactRequests(): Promise<ContactRequest[]>;
  updateContactRequestStatus(id: number, status: string): Promise<void>;
  
  // Service request operations
  createServiceRequest(request: InsertServiceRequest & { userId?: number }): Promise<ServiceRequest>;
  getServiceRequests(): Promise<ServiceRequest[]>;
  getUserServiceRequests(userId: number): Promise<ServiceRequest[]>;
  
  // Blog operations
  getBlogPosts(): Promise<BlogPost[]>;
  getPublishedBlogPosts(): Promise<BlogPost[]>;
  getBlogPost(id: number): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  
  // Crypto stats operations
  getCryptoStats(): Promise<CryptoStats[]>;
  updateCryptoStats(symbol: string, data: Partial<CryptoStats>): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize with some sample blog posts
    this.seedBlogPosts();
  }

  private async seedBlogPosts() {
    try {
      // Check if we already have blog posts
      const existingPosts = await db.select().from(blogPosts).limit(1);
      if (existingPosts.length > 0) return;

      const samplePosts = [
        {
          title: "5 Essential Steps to Secure Your Crypto Wallet",
          content: "Learn the fundamental security practices that can prevent crypto theft and ensure your digital assets remain safe...",
          excerpt: "Learn the fundamental security practices that can prevent crypto theft and ensure your digital assets remain safe...",
          category: "Security",
          imageUrl: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0",
          published: true,
        },
        {
          title: "How We Recovered $2M in Lost Bitcoin",
          content: "A detailed case study of our most challenging recovery operation involving corrupted hardware wallets...",
          excerpt: "A detailed case study of our most challenging recovery operation involving corrupted hardware wallets...",
          category: "Recovery",
          imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71",
          published: true,
        },
        {
          title: "Crypto Market Trends: What to Watch in 2025",
          content: "Expert analysis of emerging cryptocurrency trends and their implications for asset security...",
          excerpt: "Expert analysis of emerging cryptocurrency trends and their implications for asset security...",
          category: "Market Analysis",
          imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3",
          published: true,
        },
      ];

      await db.insert(blogPosts).values(samplePosts);
    } catch (error) {
      console.error('Error seeding blog posts:', error);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Contact request operations
  async createContactRequest(request: InsertContactRequest): Promise<ContactRequest> {
    const [contactRequest] = await db
      .insert(contactRequests)
      .values(request)
      .returning();
    return contactRequest;
  }

  async getContactRequests(): Promise<ContactRequest[]> {
    return await db.select().from(contactRequests);
  }

  async updateContactRequestStatus(id: number, status: string): Promise<void> {
    await db
      .update(contactRequests)
      .set({ status })
      .where(eq(contactRequests.id, id));
  }

  // Service request operations
  async createServiceRequest(request: InsertServiceRequest & { userId?: number }): Promise<ServiceRequest> {
    const [serviceRequest] = await db
      .insert(serviceRequests)
      .values(request)
      .returning();
    return serviceRequest;
  }

  async getServiceRequests(): Promise<ServiceRequest[]> {
    return await db.select().from(serviceRequests);
  }

  async getUserServiceRequests(userId: number): Promise<ServiceRequest[]> {
    return await db.select().from(serviceRequests).where(eq(serviceRequests.userId, userId));
  }

  // Blog operations
  async getBlogPosts(): Promise<BlogPost[]> {
    return await db.select().from(blogPosts);
  }

  async getPublishedBlogPosts(): Promise<BlogPost[]> {
    return await db.select().from(blogPosts).where(eq(blogPosts.published, true));
  }

  async getBlogPost(id: number): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, id));
    return post || undefined;
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const [blogPost] = await db
      .insert(blogPosts)
      .values(post)
      .returning();
    return blogPost;
  }

  // Crypto stats operations
  async getCryptoStats(): Promise<CryptoStats[]> {
    return await db.select().from(cryptoStats);
  }

  async updateCryptoStats(symbol: string, data: Partial<CryptoStats>): Promise<void> {
    const [existing] = await db.select().from(cryptoStats).where(eq(cryptoStats.symbol, symbol));
    
    if (existing) {
      await db
        .update(cryptoStats)
        .set({ ...data, updatedAt: new Date() })
        .where(eq(cryptoStats.symbol, symbol));
    } else {
      await db.insert(cryptoStats).values({
        symbol,
        name: data.name || symbol,
        price: data.price || "0",
        change24h: data.change24h || "0",
        marketCap: data.marketCap || "0",
        updatedAt: new Date(),
      });
    }
  }
}

export const storage = new DatabaseStorage();