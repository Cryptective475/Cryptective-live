import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactRequestSchema, insertServiceRequestSchema, insertUserSchema } from "@shared/schema";
import nodemailer from "nodemailer";

// Email configuration
const createTransporter = () => {
  return nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER || 'davecarter645@gmail.com',
      pass: process.env.EMAIL_PASS || process.env.GMAIL_APP_PASSWORD
    }
  });
};

const sendNotificationEmail = async (subject: string, text: string, html?: string) => {
  try {
    const transporter = createTransporter();
    await transporter.sendMail({
      from: 'support@cryptective.xyz',
      to: 'davecarter645@gmail.com',
      subject,
      text,
      html
    });
  } catch (error) {
    console.error('Failed to send notification email:', error);
  }
};

const sendAutoReply = async (to: string, subject: string, text: string, html?: string) => {
  try {
    const transporter = createTransporter();
    await transporter.sendMail({
      from: 'support@cryptective.xyz',
      to,
      subject,
      text,
      html
    });
  } catch (error) {
    console.error('Failed to send auto-reply email:', error);
  }
};

const fetchCryptoStats = async () => {
  try {
    const apiKey = process.env.COINGECKO_API_KEY || 'CG-8vgSoYf5XjpW6t1DJiELegJm';
    const symbols = ['bitcoin', 'ethereum', 'binancecoin', 'tether'];
    
    const response = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${symbols.join(',')}&vs_currencies=usd&include_24hr_change=true&include_market_cap=true`,
      {
        headers: {
          'X-CG-Demo-API-Key': apiKey
        }
      }
    );
    
    if (!response.ok) {
      throw new Error(`CoinGecko API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Update storage with latest data
    for (const [id, coinData] of Object.entries(data)) {
      const symbol = id === 'bitcoin' ? 'BTC' : 
                   id === 'ethereum' ? 'ETH' : 
                   id === 'binancecoin' ? 'BNB' : 'USDT';
      
      const typedCoinData = coinData as any;
      await storage.updateCryptoStats(symbol, {
        name: symbol,
        price: typedCoinData.usd?.toString() || "0",
        change24h: typedCoinData.usd_24h_change?.toString() || "0",
        marketCap: typedCoinData.usd_market_cap?.toString() || "0"
      });
    }
    
    return data;
  } catch (error) {
    console.error('Error fetching crypto stats:', error);
    return null;
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize crypto stats
  fetchCryptoStats();
  
  // Update crypto stats every 5 minutes
  setInterval(fetchCryptoStats, 5 * 60 * 1000);

  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactRequestSchema.parse(req.body);
      const contactRequest = await storage.createContactRequest(validatedData);
      
      // Send notification to admin
      await sendNotificationEmail(
        `New Contact Request - ${validatedData.serviceType || 'General'}`,
        `New contact request from ${validatedData.fullName}:
        
Email: ${validatedData.email}
Phone: ${validatedData.phone}
Preferred Contact: ${validatedData.preferredContact}
Service Type: ${validatedData.serviceType || 'Not specified'}
Description: ${validatedData.description || 'None provided'}

Please respond within 24 hours.`
      );
      
      // Send auto-reply to client
      await sendAutoReply(
        validatedData.email,
        'Thank you for contacting Cryptective - We received your request',
        `Dear ${validatedData.fullName},

Thank you for reaching out to Cryptective. We have received your ${validatedData.serviceType || 'general'} inquiry and a certified recovery specialist will contact you within 24 hours via ${validatedData.preferredContact}.

Your request details:
- Service Type: ${validatedData.serviceType || 'General inquiry'}
- Preferred Contact Method: ${validatedData.preferredContact}

For urgent matters, please reply to this email with "URGENT" in the subject line.

Best regards,
Cryptective Support Team
support@cryptective.xyz`
      );
      
      res.json({ success: true, id: contactRequest.id });
    } catch (error) {
      console.error('Contact form error:', error);
      res.status(400).json({ error: 'Invalid form data' });
    }
  });

  // Service request submission
  app.post("/api/service-request", async (req, res) => {
    try {
      const validatedData = insertServiceRequestSchema.parse(req.body);
      const serviceRequest = await storage.createServiceRequest(validatedData);
      
      // Send notification to admin
      await sendNotificationEmail(
        `🚨 New Service Request - ${validatedData.serviceType} (${validatedData.tier})`,
        `NEW SERVICE REQUEST SUBMITTED

Client Information:
• Name: ${validatedData.fullName}
• Email: ${validatedData.email}
• Phone: ${validatedData.phone}
• Preferred Contact: ${validatedData.preferredContact}

Service Details:
• Service: ${validatedData.serviceType}
• Tier: ${validatedData.tier}
• Amount: $${validatedData.amount} (${validatedData.currency})
• Description: ${validatedData.description || 'None provided'}

Request ID: ${serviceRequest.id}
Status: Pending Payment Confirmation

URGENT: Contact client within 24 hours to confirm payment and begin recovery process.`
      );
      
      // Send auto-reply to client
      await sendAutoReply(
        validatedData.email,
        'Service Request Received - Payment Instructions Enclosed',
        `Dear ${validatedData.fullName},

Thank you for choosing Cryptective for your ${validatedData.serviceType} needs. We have received your ${validatedData.tier} tier service request.

SERVICE SUMMARY:
• Service: ${validatedData.serviceType}
• Tier: ${validatedData.tier}
• Amount: $${validatedData.amount}

NEXT STEPS:
1. A certified recovery specialist will contact you within 24 hours via ${validatedData.preferredContact}
2. They will provide payment confirmation instructions and service agreement
3. Upon payment confirmation, your recovery process will begin immediately

IMPORTANT: Please keep this email for your records. Your request ID is: ${serviceRequest.id}

For urgent matters, please reply to this email or contact us at support@cryptective.xyz

Best regards,
Cryptective Recovery Team
Professional Cryptocurrency Recovery Services`
      );
      
      res.json({ success: true, id: serviceRequest.id });
    } catch (error) {
      console.error('Service request error:', error);
      res.status(400).json({ error: 'Invalid service request data' });
    }
  });

  // User registration
  app.post("/api/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ error: 'User already exists' });
      }
      
      const user = await storage.createUser(validatedData);
      
      // Send notification to admin
      await sendNotificationEmail(
        'New User Registration',
        `New user registered:
        
Name: ${validatedData.firstName} ${validatedData.lastName}
Email: ${validatedData.email}
Username: ${validatedData.username}
Phone: ${validatedData.phone || 'Not provided'}`
      );
      
      res.json({ success: true, userId: user.id });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(400).json({ error: 'Invalid registration data' });
    }
  });

  // Get crypto stats
  app.get("/api/crypto-stats", async (req, res) => {
    try {
      const stats = await storage.getCryptoStats();
      res.json(stats);
    } catch (error) {
      console.error('Crypto stats error:', error);
      res.status(500).json({ error: 'Failed to fetch crypto stats' });
    }
  });

  // Get blog posts
  app.get("/api/blog", async (req, res) => {
    try {
      const posts = await storage.getPublishedBlogPosts();
      res.json(posts);
    } catch (error) {
      console.error('Blog posts error:', error);
      res.status(500).json({ error: 'Failed to fetch blog posts' });
    }
  });

  // Get single blog post
  app.get("/api/blog/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const post = await storage.getBlogPost(id);
      if (!post || !post.published) {
        return res.status(404).json({ error: 'Blog post not found' });
      }
      res.json(post);
    } catch (error) {
      console.error('Blog post error:', error);
      res.status(500).json({ error: 'Failed to fetch blog post' });
    }
  });

  // Get contact requests (admin)
  app.get("/api/admin/contacts", async (req, res) => {
    try {
      const contacts = await storage.getContactRequests();
      res.json(contacts);
    } catch (error) {
      console.error('Admin contacts error:', error);
      res.status(500).json({ error: 'Failed to fetch contact requests' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
