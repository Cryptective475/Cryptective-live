# Cryptective - Cryptocurrency Recovery Platform

## Overview

Cryptective is a professional cryptocurrency recovery and security service platform built as a full-stack web application. The system provides wallet recovery, transaction recovery, security audits, and consultation services for cryptocurrency users who have lost access to their digital assets.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: TailwindCSS with custom crypto-themed design system
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack Query (React Query) for server state
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Email Service**: Nodemailer with Gmail integration
- **Session Management**: Connect-pg-simple for PostgreSQL session storage

### Monorepo Structure
```
├── client/          # React frontend application
├── server/          # Express.js backend API
├── shared/          # Shared TypeScript schemas and types
├── migrations/      # Database migration files
└── dist/           # Production build output
```

## Key Components

### Database Schema
The application uses a PostgreSQL database with the following main tables:
- **users**: User account management with authentication
- **contact_requests**: Customer inquiry and contact form submissions
- **service_requests**: Cryptocurrency recovery service requests
- **blog_posts**: Content management for crypto insights and news

### API Architecture
- RESTful API endpoints under `/api` prefix
- Real-time crypto price data integration with CoinGecko API
- Email notification system for admin alerts and customer communications
- File upload handling for recovery case documentation

### Frontend Features
- **Responsive Design**: Mobile-first approach with dark theme
- **Service Pages**: Dedicated pages for services, about, blog, contact, FAQ
- **Live Data**: Real-time cryptocurrency price ticker
- **Payment Integration**: Multi-currency wallet address display with QR codes
- **Form Handling**: Contact forms, service requests, and user registration

### Security Features
- **Input Validation**: Zod schema validation for all forms
- **CORS Configuration**: Secure cross-origin request handling
- **Environment Variables**: Sensitive data protection
- **Session Security**: Secure session management with PostgreSQL storage

## Data Flow

1. **User Interaction**: Users interact with React components in the browser
2. **API Communication**: TanStack Query manages HTTP requests to Express.js backend
3. **Database Operations**: Drizzle ORM handles PostgreSQL database queries
4. **External Services**: Integration with CoinGecko API for crypto data and Gmail for email notifications
5. **Real-time Updates**: Periodic data fetching for live cryptocurrency prices

## External Dependencies

### Core Technologies
- **Database**: Neon PostgreSQL serverless database
- **Email Service**: Gmail SMTP for notifications and auto-replies
- **Crypto Data**: CoinGecko API for real-time cryptocurrency prices
- **Payments**: Multiple cryptocurrency wallet addresses for service payments

### Development Tools
- **TypeScript**: Full-stack type safety
- **ESBuild**: Fast production bundling
- **Drizzle Kit**: Database schema management and migrations
- **Replit**: Development environment and deployment platform

## Deployment Strategy

### Development Environment
- **Platform**: Replit with Node.js 20, Web, and PostgreSQL 16 modules
- **Hot Reload**: Vite development server with HMR
- **Database**: Automatic PostgreSQL provisioning through Replit

### Production Build
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: ESBuild bundles Express server to `dist/index.js`
- **Database**: Drizzle migrations applied via `npm run db:push`
- **Deployment**: Replit autoscale deployment target

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **EMAIL_USER**: Gmail account for notifications
- **EMAIL_PASS**: Gmail app password for SMTP
- **COINGECKO_API_KEY**: API key for cryptocurrency data

## Recent Changes
- **June 27, 2025**: Complete service request flow implementation
  - Added comprehensive service selection with 4-step process
  - Integrated crypto payment options with QR codes and wallet addresses  
  - Enhanced email notification system for admin alerts and client confirmations
  - Implemented live support chat widget with priority levels
  - Added functional wallet connection with MetaMask, WalletConnect, and other providers
  - Fixed all navigation and routing issues
  - Improved user experience with better service tiers and payment flow

- **June 27, 2025**: Database Integration Completed
  - Migrated from in-memory storage to PostgreSQL database
  - Added session storage table for authentication support
  - Created comprehensive database schema with all required tables
  - Successfully seeded blog posts and crypto statistics data
  - Implemented DatabaseStorage class with full CRUD operations
  - All data persistence now handled through Neon PostgreSQL

## Changelog
- June 27, 2025. Initial setup
- June 27, 2025. Enhanced service selection flow and payment integration

## User Preferences

Preferred communication style: Simple, everyday language.
Design preferences: Keep existing crypto-themed dark design, maintain logo and branding.