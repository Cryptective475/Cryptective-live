import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Rocket, Play } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="gradient-bg py-20">
      <div className="container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Professional <span className="text-crypto-blue">Crypto Recovery</span> & 
            <span className="text-crypto-green"> Security Services</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Trusted by thousands worldwide. We specialize in recovering lost cryptocurrencies, 
            securing digital assets, and providing comprehensive blockchain security solutions.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/contact">
              <Button className="crypto-button-blue crypto-glow px-8 py-4 text-lg font-semibold">
                <Rocket className="mr-2 h-5 w-5" />
                Start Recovery Process
              </Button>
            </Link>
            <Button variant="outline" className="border-crypto-green text-crypto-green hover:bg-crypto-green hover:text-white px-8 py-4 text-lg font-semibold">
              <Play className="mr-2 h-5 w-5" />
              Watch Demo
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-crypto-green">98%</div>
              <div className="text-gray-400">Success Rate</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-crypto-blue">$50M+</div>
              <div className="text-gray-400">Recovered</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-crypto-gold">5000+</div>
              <div className="text-gray-400">Clients Served</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-white">24/7</div>
              <div className="text-gray-400">Support</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
