import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

export default function LiveStatsWidget() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/crypto-stats"],
    refetchInterval: 60000, // Refetch every minute
  });

  if (isLoading) {
    return (
      <div className="bg-crypto-slate/50 border-b border-gray-700">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-center space-x-8">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-6 w-32" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const getIcon = (symbol: string) => {
    switch (symbol) {
      case 'BTC': return 'fab fa-bitcoin text-crypto-gold';
      case 'ETH': return 'fab fa-ethereum text-crypto-blue';
      case 'BNB': return 'fas fa-coins text-crypto-gold';
      case 'USDT': return 'fas fa-dollar-sign text-crypto-green';
      default: return 'fas fa-coins';
    }
  };

  const formatPrice = (price: string) => {
    const num = parseFloat(price);
    return num >= 1 ? `$${num.toLocaleString()}` : `$${num.toFixed(4)}`;
  };

  const formatChange = (change: string) => {
    const num = parseFloat(change);
    const isPositive = num >= 0;
    return (
      <span className={isPositive ? "text-crypto-green" : "text-red-400"}>
        {isPositive ? '+' : ''}{num.toFixed(1)}%
      </span>
    );
  };

  return (
    <div className="bg-crypto-slate/50 border-b border-gray-700">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-center space-x-8 text-sm overflow-x-auto">
          {stats?.map((stat) => (
            <div key={stat.symbol} className="flex items-center space-x-2 whitespace-nowrap">
              <i className={getIcon(stat.symbol)}></i>
              <span>{stat.symbol}: {formatPrice(stat.price)}</span>
              {formatChange(stat.change24h || "0")}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
