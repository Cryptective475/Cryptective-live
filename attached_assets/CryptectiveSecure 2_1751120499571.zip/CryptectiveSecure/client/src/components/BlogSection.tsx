import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

export default function BlogSection() {
  const { data: posts, isLoading } = useQuery({
    queryKey: ["/api/blog"],
  });

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'security': return 'text-crypto-blue';
      case 'recovery': return 'text-crypto-green';
      case 'market analysis': return 'text-crypto-gold';
      default: return 'text-gray-400';
    }
  };

  if (isLoading) {
    return (
      <section id="blog" className="py-20 bg-crypto-dark">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Latest Crypto Insights</h2>
            <p className="text-xl text-gray-400">Stay updated with the latest news and recovery techniques</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="crypto-card">
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-6">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-6 w-full mb-3" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="blog" className="py-20 bg-crypto-dark">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Latest Crypto Insights</h2>
          <p className="text-xl text-gray-400">Stay updated with the latest news and recovery techniques</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {posts?.slice(0, 3).map((post) => (
            <Card key={post.id} className="crypto-card border-gray-700 hover:border-crypto-blue transition-all overflow-hidden">
              <img
                src={post.imageUrl || "https://images.unsplash.com/photo-1639762681485-074b7f938ba0"}
                alt={post.title}
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-6">
                <div className={`flex items-center space-x-2 text-sm mb-3`}>
                  <span className={getCategoryColor(post.category)}>{post.category}</span>
                  <span>•</span>
                  <span className="text-gray-400">
                    {new Date(post.createdAt).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric', 
                      year: 'numeric' 
                    })}
                  </span>
                </div>
                <h3 className="text-xl font-bold mb-3">{post.title}</h3>
                <p className="text-gray-400 mb-4">{post.excerpt}</p>
                <Link href={`/blog/${post.id}`}>
                  <a className={`${getCategoryColor(post.category)} hover:opacity-80 font-semibold`}>
                    Read More →
                  </a>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/blog">
            <Button className="crypto-button-blue">
              View All Articles
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
