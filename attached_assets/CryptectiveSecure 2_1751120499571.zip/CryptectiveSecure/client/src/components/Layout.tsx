import Header from "./Header";
import Footer from "./Footer";
import LiveSupportWidget from "./LiveSupportWidget";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen transition-colors duration-300" style={{
      backgroundColor: 'var(--background)',
      color: 'var(--foreground)'
    }}>
      <Header />
      <main>{children}</main>
      <Footer />
      <LiveSupportWidget />
    </div>
  );
}
