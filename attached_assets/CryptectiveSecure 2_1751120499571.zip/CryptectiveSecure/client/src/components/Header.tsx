import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Shield } from "lucide-react";
import WalletConnect from "./WalletConnect";
import ThemeSwitcher from "./ThemeSwitcher";

export default function Header() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/about", label: "About" },
    { href: "/token-info", label: "Token Info" },
    { href: "/blog", label: "Blog" },
    { href: "/contact", label: "Contact" },
    { href: "/faq", label: "FAQ" },
  ];

  const NavLinks = ({ mobile = false, onItemClick = () => {} }) => (
    <>
      {navItems.map((item) => (
        <Link key={item.href} href={item.href}>
          <span
            className={`text-gray-300 hover:text-crypto-blue transition-colors cursor-pointer ${
              location === item.href ? "text-crypto-blue" : ""
            } ${mobile ? "block py-2" : ""}`}
            onClick={onItemClick}
          >
            {item.label}
          </span>
        </Link>
      ))}
    </>
  );

  return (
    <header className="bg-crypto-slate/90 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-50">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center space-x-2">
              <Shield className="text-crypto-blue text-2xl" />
              <span className="text-2xl font-bold text-white">Cryptective</span>
              <span className="text-xs bg-crypto-green px-2 py-1 rounded-full text-white">SECURE</span>
            </a>
          </Link>
          
          <div className="hidden md:flex space-x-8">
            <NavLinks />
          </div>

          <div className="flex items-center space-x-4">
            <ThemeSwitcher />
            <WalletConnect />
            <Link href="/login">
              <span className="text-gray-300 hover:text-crypto-blue cursor-pointer">Login</span>
            </Link>
            <Link href="/signup">
              <span className="crypto-button-green px-4 py-2 rounded-lg text-white transition-colors cursor-pointer">Sign Up</span>
            </Link>

            {/* Mobile menu */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-crypto-dark border-gray-700">
                <div className="flex flex-col space-y-4 mt-8">
                  <NavLinks mobile onItemClick={() => setIsOpen(false)} />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </nav>
    </header>
  );
}
