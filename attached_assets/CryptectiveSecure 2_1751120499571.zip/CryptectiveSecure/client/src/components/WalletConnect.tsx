import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Wallet, ExternalLink, Copy, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const wallets = [
  {
    name: "MetaMask",
    icon: "🦊",
    description: "Connect using MetaMask browser extension",
    type: "browser"
  },
  {
    name: "WalletConnect",
    icon: "📱",
    description: "Connect with mobile wallet via QR code",
    type: "mobile"
  },
  {
    name: "Coinbase Wallet",
    icon: "🔵",
    description: "Connect using Coinbase Wallet",
    type: "browser"
  },
  {
    name: "Trust Wallet",
    icon: "🛡️",
    description: "Connect with Trust Wallet mobile app",
    type: "mobile"
  }
];

export default function WalletConnect() {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [connected, setConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState("");

  const connectWallet = async (walletName: string) => {
    // Simulate wallet connection
    try {
      // In a real implementation, this would integrate with Web3Modal or similar
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockAddress = "0x742d...A3F2"; // Simulated address
      setWalletAddress(mockAddress);
      setConnected(true);
      setIsOpen(false);
      
      toast({
        title: "Wallet Connected",
        description: `Successfully connected ${walletName}`,
      });
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: "Please try again or contact support",
        variant: "destructive",
      });
    }
  };

  const disconnectWallet = () => {
    setConnected(false);
    setWalletAddress("");
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been safely disconnected",
    });
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(walletAddress);
    toast({
      title: "Address Copied",
      description: "Wallet address copied to clipboard",
    });
  };

  if (connected) {
    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button className="crypto-button-green">
            <CheckCircle className="mr-2 h-4 w-4" />
            {walletAddress}
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-crypto-dark border-gray-700">
          <DialogHeader>
            <DialogTitle>Connected Wallet</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-crypto-green/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-crypto-green" />
              </div>
              <p className="text-gray-400">Wallet successfully connected</p>
            </div>
            
            <div className="bg-crypto-slate p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Address:</span>
                <div className="flex items-center space-x-2">
                  <span className="font-mono">{walletAddress}</span>
                  <Button size="sm" variant="ghost" onClick={copyAddress}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <p className="text-sm text-gray-400">What you can do:</p>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-crypto-green" />
                  <span>Make secure payments directly from your wallet</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-crypto-green" />
                  <span>Verify ownership for recovery services</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-crypto-green" />
                  <span>Access premium features and discounts</span>
                </div>
              </div>
            </div>

            <Button onClick={disconnectWallet} variant="outline" className="w-full">
              Disconnect Wallet
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="crypto-button-blue">
          <Wallet className="mr-2 h-4 w-4" />
          Connect Wallet
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-crypto-dark border-gray-700">
        <DialogHeader>
          <DialogTitle>Connect Your Wallet</DialogTitle>
        </DialogHeader>
        <div className="space-y-6">
          <p className="text-gray-400 text-center">
            Connect your cryptocurrency wallet to make secure payments and verify ownership
          </p>
          
          <div className="grid gap-3">
            {wallets.map((wallet, index) => (
              <Card key={index} className="crypto-card border-gray-700 hover:border-crypto-blue transition-all cursor-pointer">
                <CardContent className="p-4">
                  <div 
                    className="flex items-center justify-between"
                    onClick={() => connectWallet(wallet.name)}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{wallet.icon}</span>
                      <div>
                        <h3 className="font-semibold">{wallet.name}</h3>
                        <p className="text-sm text-gray-400">{wallet.description}</p>
                      </div>
                    </div>
                    <ExternalLink className="h-4 w-4 text-gray-400" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <p className="text-xs text-gray-500 mb-2">
              Don't have a wallet? We recommend:
            </p>
            <div className="flex justify-center space-x-4">
              <a href="https://metamask.io" target="_blank" rel="noopener noreferrer" className="text-crypto-blue hover:text-blue-400 text-sm">
                Get MetaMask
              </a>
              <a href="https://trustwallet.com" target="_blank" rel="noopener noreferrer" className="text-crypto-blue hover:text-blue-400 text-sm">
                Get Trust Wallet
              </a>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}