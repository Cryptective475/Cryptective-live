import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mail, Clock, Headphones, Layers, Shield, MessageCircle } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ContactSection() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    preferredContact: "",
    serviceType: "",
    description: "",
  });

  const contactMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      await apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Request Submitted",
        description: "Thank you! A recovery specialist will contact you within 24 hours.",
      });
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        preferredContact: "",
        serviceType: "",
        description: "",
      });
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: "Please check your information and try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.email || !formData.phone || !formData.preferredContact) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-20 bg-crypto-slate">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Get Professional Help</h2>
            <p className="text-xl text-gray-400">
              Start your crypto recovery process today. Our experts will reach out within 24 hours.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold mb-6">Service Request Form</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300 mb-2">Full Name *</Label>
                    <Input
                      required
                      className="crypto-input"
                      value={formData.fullName}
                      onChange={(e) => handleInputChange('fullName', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300 mb-2">Phone Number *</Label>
                    <Input
                      type="tel"
                      required
                      className="crypto-input"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                    />
                  </div>
                </div>
                
                <div>
                  <Label className="text-gray-300 mb-2">Primary Email *</Label>
                  <Input
                    type="email"
                    required
                    className="crypto-input"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                  />
                </div>

                <div>
                  <Label className="text-gray-300 mb-2">Preferred Contact Method *</Label>
                  <Select value={formData.preferredContact} onValueChange={(value) => handleInputChange('preferredContact', value)}>
                    <SelectTrigger className="crypto-input">
                      <SelectValue placeholder="Select method..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="phone">Phone</SelectItem>
                      <SelectItem value="whatsapp">WhatsApp</SelectItem>
                      <SelectItem value="telegram">Telegram</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-gray-300 mb-2">Service Type</Label>
                  <Select value={formData.serviceType} onValueChange={(value) => handleInputChange('serviceType', value)}>
                    <SelectTrigger className="crypto-input">
                      <SelectValue placeholder="Select service..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="wallet-recovery">Wallet Recovery</SelectItem>
                      <SelectItem value="transaction-recovery">Transaction Recovery</SelectItem>
                      <SelectItem value="security-audit">Security Audit</SelectItem>
                      <SelectItem value="consultation">Consultation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-gray-300 mb-2">Case Description</Label>
                  <Textarea
                    rows={4}
                    className="crypto-input"
                    placeholder="Please describe your situation in detail..."
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full crypto-button-blue text-lg py-4"
                  disabled={contactMutation.isPending}
                >
                  <Layers className="mr-2 h-5 w-5" />
                  {contactMutation.isPending ? "Submitting..." : "Submit Request"}
                </Button>

                <p className="text-sm text-gray-400 text-center">
                  <Shield className="inline text-crypto-green mr-1 h-4 w-4" />
                  A certified recovery specialist will contact you within 24 hours
                </p>
              </form>
            </div>

            <div>
              <h3 className="text-2xl font-bold mb-6">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-crypto-blue/20 rounded-full flex items-center justify-center">
                    <Mail className="text-crypto-blue h-6 w-6" />
                  </div>
                  <div>
                    <div className="font-semibold">Email Support</div>
                    <div className="text-gray-400">support@cryptective.xyz</div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-crypto-green/20 rounded-full flex items-center justify-center">
                    <Clock className="text-crypto-green h-6 w-6" />
                  </div>
                  <div>
                    <div className="font-semibold">Response Time</div>
                    <div className="text-gray-400">Within 24 hours</div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-crypto-gold/20 rounded-full flex items-center justify-center">
                    <Headphones className="text-crypto-gold h-6 w-6" />
                  </div>
                  <div>
                    <div className="font-semibold">24/7 Emergency</div>
                    <div className="text-gray-400">For critical cases</div>
                  </div>
                </div>
              </div>

              <Card className="mt-8 crypto-card border-gray-700">
                <CardContent className="p-6">
                  <h4 className="text-lg font-bold mb-4">Need Immediate Help?</h4>
                  <p className="text-gray-400 mb-4">Our live support team is available for urgent recovery cases.</p>
                  <Button className="w-full crypto-button-green">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Start Live Chat
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
