import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Copy, QrCode } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const walletAddresses = [
  {
    name: "Bitcoin (BTC)",
    symbol: "BTC",
    address: "bc1q64ddhqdhj6k9dsdxzp732vypysnrlqgtxnkz3r",
    network: "Bech32",
    icon: "fab fa-bitcoin",
    color: "crypto-gold",
  },
  {
    name: "Ethereum (ETH)",
    symbol: "ETH",
    address: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e",
    network: "ERC20",
    icon: "fab fa-ethereum",
    color: "crypto-blue",
  },
  {
    name: "USDT",
    symbol: "USDT",
    address: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e",
    network: "ERC20",
    icon: "fas fa-dollar-sign",
    color: "crypto-green",
  },
  {
    name: "USDT",
    symbol: "USDT",
    address: "TK3VqoZz9ytane8mFQYZY2qkhEXpSFD1N8",
    network: "TRC20",
    icon: "fas fa-dollar-sign",
    color: "crypto-green",
  },
  {
    name: "Solana (SOL)",
    symbol: "SOL",
    address: "5bNPoCXfv1HjBpd769arF4msVGgxjqEKB18ujZ8eZ1a4",
    network: "Native",
    icon: "fas fa-coins",
    color: "purple-400",
  },
  {
    name: "BNB",
    symbol: "BNB",
    address: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e",
    network: "BSC",
    icon: "fas fa-coins",
    color: "crypto-gold",
  },
];

export default function PaymentSection() {
  const { toast } = useToast();
  const [selectedWallet, setSelectedWallet] = useState<typeof walletAddresses[0] | null>(null);

  const copyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    toast({
      title: "Address Copied",
      description: "Wallet address copied to clipboard",
    });
  };

  const generateQRCode = (address: string) => {
    // Using QR Server for QR code generation
    return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(address)}`;
  };

  return (
    <section className="py-20 bg-crypto-dark">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Secure Crypto Payments</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            We accept payments in multiple cryptocurrencies. All transactions are secure and verified.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {walletAddresses.map((wallet, index) => (
            <Card key={index} className="crypto-card border-gray-700 hover:border-crypto-blue transition-all">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <i className={`${wallet.icon} text-${wallet.color} text-2xl`}></i>
                    <span className="text-xl font-bold">{wallet.name}</span>
                  </div>
                  <span className="text-sm text-gray-400">{wallet.network}</span>
                </div>
                
                <div className="bg-crypto-dark p-4 rounded-lg mb-4">
                  <div className="text-sm font-mono text-gray-300 break-all">
                    {wallet.address}
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-crypto-blue hover:text-blue-400"
                    onClick={() => copyAddress(wallet.address)}
                  >
                    <Copy className="mr-1 h-4 w-4" />
                    Copy Address
                  </Button>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-crypto-green hover:text-emerald-400"
                        onClick={() => setSelectedWallet(wallet)}
                      >
                        <QrCode className="mr-1 h-4 w-4" />
                        Show QR
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-crypto-dark border-gray-700">
                      <DialogHeader>
                        <DialogTitle className="text-center">{selectedWallet?.name} Address</DialogTitle>
                      </DialogHeader>
                      <div className="text-center p-6">
                        <img
                          src={generateQRCode(selectedWallet?.address || "")}
                          alt="QR Code"
                          className="mx-auto mb-4 rounded-lg"
                        />
                        <p className="text-sm text-gray-400 font-mono break-all">
                          {selectedWallet?.address}
                        </p>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-400 mb-4">Don't see your preferred cryptocurrency?</p>
          <Button className="crypto-button-green">
            <i className="fas fa-envelope mr-2"></i>
            Contact Us for Other Coins
          </Button>
        </div>
      </div>
    </section>
  );
}
