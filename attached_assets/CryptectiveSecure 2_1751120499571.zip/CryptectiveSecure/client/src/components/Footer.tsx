import { Link } from "wouter";
import { Shield } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-crypto-dark border-t border-gray-700 py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <Shield className="text-crypto-blue text-2xl" />
              <span className="text-2xl font-bold text-white">Cryptective</span>
            </div>
            <p className="text-gray-400 mb-6">
              Professional cryptocurrency recovery and security services trusted by thousands worldwide.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-crypto-blue transition-colors">
                <i className="fab fa-twitter text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-crypto-blue transition-colors">
                <i className="fab fa-linkedin text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-crypto-blue transition-colors">
                <i className="fab fa-telegram text-xl"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Services</h3>
            <ul className="space-y-3 text-gray-400">
              <li><Link href="/services"><a className="hover:text-crypto-blue transition-colors">Wallet Recovery</a></Link></li>
              <li><Link href="/services"><a className="hover:text-crypto-blue transition-colors">Transaction Recovery</a></Link></li>
              <li><Link href="/services"><a className="hover:text-crypto-blue transition-colors">Security Audit</a></Link></li>
              <li><Link href="/services"><a className="hover:text-crypto-blue transition-colors">Consultation</a></Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Company</h3>
            <ul className="space-y-3 text-gray-400">
              <li><Link href="/about"><a className="hover:text-crypto-blue transition-colors">About Us</a></Link></li>
              <li><Link href="/blog"><a className="hover:text-crypto-blue transition-colors">Blog</a></Link></li>
              <li><a href="#" className="hover:text-crypto-blue transition-colors">Careers</a></li>
              <li><Link href="/contact"><a className="hover:text-crypto-blue transition-colors">Contact</a></Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Support</h3>
            <ul className="space-y-3 text-gray-400">
              <li><Link href="/faq"><a className="hover:text-crypto-blue transition-colors">FAQ</a></Link></li>
              <li><a href="#" className="hover:text-crypto-blue transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-crypto-blue transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-crypto-blue transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Cryptective. All rights reserved. | Professional Crypto Recovery Services</p>
        </div>
      </div>
    </footer>
  );
}
