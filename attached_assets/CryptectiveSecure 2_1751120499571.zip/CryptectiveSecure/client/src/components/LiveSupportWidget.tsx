import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, X, Send, Clock, Shield, Headphones } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function LiveSupportWidget() {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [chatStarted, setChatStarted] = useState(false);
  const [supportData, setSupportData] = useState({
    name: "",
    email: "",
    priority: "normal",
    message: ""
  });

  const supportMutation = useMutation({
    mutationFn: async (data: typeof supportData) => {
      await apiRequest("POST", "/api/contact", {
        fullName: data.name,
        email: data.email,
        phone: "Via Live Chat",
        preferredContact: "email",
        serviceType: `Live Chat Support - ${data.priority} priority`,
        description: data.message
      });
    },
    onSuccess: () => {
      toast({
        title: "Support Request Sent",
        description: "Our team will respond to you within 24 hours via email.",
      });
      setChatStarted(true);
      setSupportData({ name: "", email: "", priority: "normal", message: "" });
    },
    onError: () => {
      toast({
        title: "Failed to send",
        description: "Please try again or contact support@cryptective.xyz",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supportData.name || !supportData.email || !supportData.message) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    supportMutation.mutate(supportData);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "bg-red-500";
      case "high": return "bg-orange-500";
      case "normal": return "bg-crypto-blue";
      default: return "bg-gray-500";
    }
  };

  return (
    <>
      {/* Floating Support Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="crypto-button-green w-16 h-16 rounded-full shadow-lg transition-all hover:scale-110 flex items-center justify-center relative">
              <MessageCircle className="text-xl h-6 w-6" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
                !
              </span>
            </Button>
          </DialogTrigger>
          
          <DialogContent className="bg-crypto-dark border-gray-700 max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Headphones className="text-crypto-green h-5 w-5" />
                <span>Live Support</span>
                <Badge className="bg-crypto-green">24/7</Badge>
              </DialogTitle>
            </DialogHeader>
            
            {!chatStarted ? (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-4 mb-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-crypto-green rounded-full animate-pulse"></div>
                      <span className="text-sm text-gray-400">Support Online</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-crypto-blue" />
                      <span className="text-sm text-gray-400">Avg. response: 2min</span>
                    </div>
                  </div>
                  <p className="text-gray-400 text-sm">
                    Get immediate help from our cryptocurrency recovery experts
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Input
                      placeholder="Your Name *"
                      className="crypto-input"
                      value={supportData.name}
                      onChange={(e) => setSupportData(prev => ({ ...prev, name: e.target.value }))}
                      required
                    />
                  </div>
                  
                  <div>
                    <Input
                      type="email"
                      placeholder="Email Address *"
                      className="crypto-input"
                      value={supportData.email}
                      onChange={(e) => setSupportData(prev => ({ ...prev, email: e.target.value }))}
                      required
                    />
                  </div>

                  <div>
                    <select
                      className="w-full crypto-input"
                      value={supportData.priority}
                      onChange={(e) => setSupportData(prev => ({ ...prev, priority: e.target.value }))}
                    >
                      <option value="normal">Normal Priority</option>
                      <option value="high">High Priority</option>
                      <option value="urgent">🚨 URGENT - Emergency Recovery</option>
                    </select>
                  </div>
                  
                  <div>
                    <Textarea
                      placeholder="Describe your issue or question... *"
                      className="crypto-input"
                      rows={3}
                      value={supportData.message}
                      onChange={(e) => setSupportData(prev => ({ ...prev, message: e.target.value }))}
                      required
                    />
                  </div>

                  <div className="flex items-center space-x-2 text-xs text-gray-400">
                    <Shield className="w-4 h-4" />
                    <span>Your information is encrypted and secure</span>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full crypto-button-green"
                    disabled={supportMutation.isPending}
                  >
                    <Send className="mr-2 h-4 w-4" />
                    {supportMutation.isPending ? "Connecting..." : "Start Live Chat"}
                  </Button>
                </form>

                <div className="text-center">
                  <p className="text-xs text-gray-500">
                    For emergencies, call: +1 (555) CRYPTO-1 (24/7)
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-crypto-green/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-8 h-8 text-crypto-green" />
                </div>
                <h3 className="text-xl font-bold mb-2">Support Request Sent!</h3>
                <p className="text-gray-400 mb-4">
                  Our team has received your request and will respond within 24 hours via email.
                </p>
                <div className="bg-crypto-slate p-4 rounded-lg mb-4">
                  <p className="text-sm text-gray-400">
                    <strong>Priority:</strong> <Badge className={getPriorityColor(supportData.priority)}>{supportData.priority}</Badge>
                  </p>
                </div>
                <Button 
                  onClick={() => {setChatStarted(false); setIsOpen(false);}} 
                  className="crypto-button-blue"
                >
                  Close Chat
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}