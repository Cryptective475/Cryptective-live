import { useState } from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqItems = [
  {
    question: "Is crypto recovery legitimate?",
    answer: "Yes, crypto recovery is a legitimate service. We use advanced cryptographic techniques and blockchain analysis to recover lost funds. Our methods are legal and ethical, and we have a proven track record with thousands of successful recoveries."
  },
  {
    question: "What are Cryptective's main services?",
    answer: "We offer wallet recovery, transaction recovery, security audits, and consultation services. Our specialties include recovering forgotten passwords, seed phrases, private keys, and funds sent to wrong addresses or stuck in smart contracts."
  },
  {
    question: "How long does recovery take?",
    answer: "Recovery time varies by case complexity. Simple wallet recoveries may take 1-3 days, while complex cases can take 1-4 weeks. Enterprise clients receive priority processing with same-day response times."
  },
  {
    question: "How do I know my payment is safe?",
    answer: "All payments are made to verified wallet addresses displayed on our site. We provide transaction confirmations and receipts. Our payment system is transparent, and you can verify all transactions on the blockchain."
  },
  {
    question: "Can I track my service progress?",
    answer: "Yes, you'll receive regular updates throughout the recovery process. Our team provides status reports and will contact you via your preferred communication method with progress updates and next steps."
  },
  {
    question: "What's the refund policy?",
    answer: "We offer a 'no recovery, no fee' policy for most services. If we cannot recover your funds, you receive a full refund minus any initial assessment fees. Specific terms vary by service tier and case complexity."
  }
];

export default function FAQSection() {
  return (
    <section id="faq" className="py-20 bg-crypto-slate">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-gray-400">Get answers to common questions about crypto recovery</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Accordion type="single" collapsible className="space-y-6">
            {faqItems.map((item, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="crypto-card border-gray-700 rounded-xl px-6"
              >
                <AccordionTrigger className="text-lg font-semibold text-left hover:no-underline hover:text-crypto-blue">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-400 pb-6">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
