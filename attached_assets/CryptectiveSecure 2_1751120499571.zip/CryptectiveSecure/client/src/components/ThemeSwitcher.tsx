import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Palette, Sun, Moon, Laptop } from "lucide-react";

type Theme = 'dark' | 'light' | 'night';

const themes = [
  {
    id: 'dark' as Theme,
    name: 'Dark',
    description: 'Crypto-themed dark mode',
    icon: Moon,
    preview: 'bg-crypto-dark border-crypto-slate'
  },
  {
    id: 'light' as Theme,
    name: 'Light',
    description: 'Clean light theme',
    icon: Sun,
    preview: 'bg-white border-gray-200'
  },
  {
    id: 'night' as Theme,
    name: 'Night Black',
    description: 'Pure black for OLED screens',
    icon: Laptop,
    preview: 'bg-black border-gray-800'
  }
];

export default function ThemeSwitcher() {
  const [currentTheme, setCurrentTheme] = useState<Theme>('dark');
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Load saved theme from localStorage
    const savedTheme = localStorage.getItem('cryptective-theme') as Theme;
    if (savedTheme && themes.find(t => t.id === savedTheme)) {
      setCurrentTheme(savedTheme);
      applyTheme(savedTheme);
    }
  }, []);

  const applyTheme = (theme: Theme) => {
    const root = document.documentElement;
    
    // Remove existing theme classes
    root.classList.remove('dark', 'light', 'night');
    
    // Add new theme class
    root.classList.add(theme);
    
    // Apply theme-specific CSS variables
    switch (theme) {
      case 'light':
        root.style.setProperty('--background', 'hsl(0, 0%, 100%)');
        root.style.setProperty('--foreground', 'hsl(240, 10%, 4%)');
        root.style.setProperty('--muted', 'hsl(240, 5%, 96%)');
        root.style.setProperty('--muted-foreground', 'hsl(240, 4%, 46%)');
        root.style.setProperty('--card', 'hsl(0, 0%, 100%)');
        root.style.setProperty('--card-foreground', 'hsl(240, 10%, 4%)');
        root.style.setProperty('--border', 'hsl(240, 6%, 90%)');
        root.style.setProperty('--crypto-dark', 'hsl(0, 0%, 98%)');
        root.style.setProperty('--crypto-slate', 'hsl(240, 5%, 96%)');
        break;
      case 'night':
        root.style.setProperty('--background', 'hsl(0, 0%, 0%)');
        root.style.setProperty('--foreground', 'hsl(0, 0%, 98%)');
        root.style.setProperty('--muted', 'hsl(0, 0%, 8%)');
        root.style.setProperty('--muted-foreground', 'hsl(0, 0%, 65%)');
        root.style.setProperty('--card', 'hsl(0, 0%, 4%)');
        root.style.setProperty('--card-foreground', 'hsl(0, 0%, 98%)');
        root.style.setProperty('--border', 'hsl(0, 0%, 15%)');
        root.style.setProperty('--crypto-dark', 'hsl(0, 0%, 0%)');
        root.style.setProperty('--crypto-slate', 'hsl(0, 0%, 8%)');
        break;
      default: // dark
        root.style.setProperty('--background', 'hsl(220, 39%, 11%)');
        root.style.setProperty('--foreground', 'hsl(0, 0%, 98%)');
        root.style.setProperty('--muted', 'hsl(217, 33%, 17%)');
        root.style.setProperty('--muted-foreground', 'hsl(215, 20%, 65%)');
        root.style.setProperty('--card', 'hsl(220, 39%, 11%)');
        root.style.setProperty('--card-foreground', 'hsl(0, 0%, 98%)');
        root.style.setProperty('--border', 'hsl(217, 33%, 17%)');
        root.style.setProperty('--crypto-dark', 'hsl(220, 39%, 11%)');
        root.style.setProperty('--crypto-slate', 'hsl(217, 33%, 17%)');
        break;
    }
  };

  const changeTheme = (theme: Theme) => {
    setCurrentTheme(theme);
    applyTheme(theme);
    localStorage.setItem('cryptective-theme', theme);
    setIsOpen(false);
  };

  const getCurrentThemeInfo = () => {
    return themes.find(t => t.id === currentTheme) || themes[0];
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="text-gray-300 hover:text-crypto-blue">
          <Palette className="h-5 w-5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-crypto-dark border-gray-700">
        <DialogHeader>
          <DialogTitle>Choose Theme</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-gray-400 text-sm">
            Select a theme that's comfortable for your eyes and viewing environment
          </p>
          
          <div className="grid gap-3">
            {themes.map((theme) => {
              const IconComponent = theme.icon;
              const isSelected = currentTheme === theme.id;
              
              return (
                <Card 
                  key={theme.id}
                  className={`cursor-pointer transition-all crypto-card ${
                    isSelected ? 'border-crypto-blue bg-crypto-blue/10' : 'border-gray-700 hover:border-crypto-blue/50'
                  }`}
                  onClick={() => changeTheme(theme.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full ${theme.preview} border-2 flex items-center justify-center`}>
                          <IconComponent className="h-4 w-4" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{theme.name}</h3>
                          <p className="text-sm text-gray-400">{theme.description}</p>
                        </div>
                      </div>
                      {isSelected && (
                        <div className="w-3 h-3 bg-crypto-blue rounded-full"></div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="text-center pt-4">
            <p className="text-xs text-gray-500">
              Your theme preference will be saved automatically
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}