import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, Shield, CheckCircle, CreditCard, Copy, QrCode } from "lucide-react";

const services = [
  {
    id: "wallet-recovery",
    name: "Wallet Recovery",
    description: "Recover lost wallet passwords, seed phrases, and private keys",
    tiers: [
      { name: "Basic", price: 499, features: ["Email Support", "Basic Recovery Tools", "7-day Turnaround"] },
      { name: "Professional", price: 899, features: ["Priority Support", "Advanced Tools", "3-day Turnaround", "Phone Consultation"] },
      { name: "Enterprise", price: 1499, features: ["24/7 Support", "Custom Solutions", "Same-day Response", "On-site Support"] }
    ]
  },
  {
    id: "transaction-recovery",
    name: "Transaction Recovery", 
    description: "Recover funds from failed transactions and wrong addresses",
    tiers: [
      { name: "Basic", price: 799, features: ["Email Support", "Standard Recovery", "5-day Turnaround"] },
      { name: "Professional", price: 1299, features: ["Priority Support", "Advanced Analysis", "2-day Turnaround", "Expert Consultation"] },
      { name: "Enterprise", price: 2199, features: ["24/7 Support", "Emergency Response", "Same-day Analysis", "Legal Support"] }
    ]
  },
  {
    id: "security-audit",
    name: "Security Audit",
    description: "Comprehensive security assessment and hardening",
    tiers: [
      { name: "Basic", price: 1299, features: ["Security Scan", "Report Generation", "10-day Delivery"] },
      { name: "Professional", price: 2199, features: ["Deep Analysis", "Custom Recommendations", "5-day Delivery", "Follow-up Call"] },
      { name: "Enterprise", price: 3499, features: ["Complete Assessment", "Implementation Support", "2-day Delivery", "Ongoing Monitoring"] }
    ]
  }
];

const cryptoPayments = [
  { symbol: "BTC", name: "Bitcoin", address: "bc1q64ddhqdhj6k9dsdxzp732vypysnrlqgtxnkz3r", network: "Native" },
  { symbol: "ETH", name: "Ethereum", address: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e", network: "ERC-20" },
  { symbol: "USDT", name: "USDT (ERC-20)", address: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e", network: "ERC-20" },
  { symbol: "USDT", name: "USDT (TRC-20)", address: "TK3VqoZz9ytane8mFQYZY2qkhEXpSFD1N8", network: "TRC-20" },
  { symbol: "SOL", name: "Solana", address: "5bNPoCXfv1HjBpd769arF4msVGgxjqEKB18ujZ8eZ1a4", network: "Native" },
  { symbol: "BNB", name: "BNB", address: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e", network: "BSC" }
];

export default function ServiceSelectionFlow() {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedService, setSelectedService] = useState<string>("");
  const [selectedTier, setSelectedTier] = useState<string>("");
  const [selectedPayment, setSelectedPayment] = useState<any>(null);
  const [contactData, setContactData] = useState({
    fullName: "",
    email: "",
    phone: "",
    preferredContact: "",
    description: ""
  });

  const serviceRequestMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/service-request", data);
    },
    onSuccess: () => {
      toast({
        title: "Service Request Submitted",
        description: "Your request has been submitted. A specialist will contact you within 24 hours to confirm payment and begin your recovery process.",
      });
      setCurrentStep(5);
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Please try again or contact support.",
        variant: "destructive",
      });
    },
  });

  const copyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    toast({
      title: "Address Copied",
      description: "Payment address copied to clipboard",
    });
  };

  const generateQRCode = (address: string) => {
    return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(address)}`;
  };

  const getSelectedServiceData = () => {
    const service = services.find(s => s.id === selectedService);
    const tier = service?.tiers.find(t => t.name === selectedTier);
    return { service, tier };
  };

  const handleSubmitRequest = () => {
    const { service, tier } = getSelectedServiceData();
    if (!service || !tier) return;

    const requestData = {
      serviceType: service.id,
      tier: tier.name,
      amount: tier.price.toString(),
      currency: selectedPayment?.symbol || "USD",
      description: contactData.description,
      fullName: contactData.fullName,
      email: contactData.email,
      phone: contactData.phone,
      preferredContact: contactData.preferredContact
    };

    serviceRequestMutation.mutate(requestData);
  };

  if (currentStep === 5) {
    return (
      <div className="max-w-2xl mx-auto text-center py-16">
        <CheckCircle className="w-16 h-16 text-crypto-green mx-auto mb-6" />
        <h2 className="text-3xl font-bold mb-4">Request Submitted Successfully!</h2>
        <p className="text-gray-400 mb-6">
          Thank you for choosing Cryptective. A certified recovery specialist will contact you within 24 hours
          via your preferred method to confirm payment details and begin your recovery process.
        </p>
        <div className="bg-crypto-slate p-6 rounded-lg mb-6">
          <h3 className="text-lg font-semibold mb-4">What happens next?</h3>
          <div className="space-y-3 text-left">
            <div className="flex items-center space-x-3">
              <Badge className="bg-crypto-blue">1</Badge>
              <span>Specialist reviews your case details</span>
            </div>
            <div className="flex items-center space-x-3">
              <Badge className="bg-crypto-green">2</Badge>
              <span>Payment confirmation and service agreement</span>
            </div>
            <div className="flex items-center space-x-3">
              <Badge className="bg-crypto-gold">3</Badge>
              <span>Recovery process begins with regular updates</span>
            </div>
          </div>
        </div>
        <Button onClick={() => {setCurrentStep(1); setSelectedService(""); setSelectedTier(""); setContactData({fullName:"",email:"",phone:"",preferredContact:"",description:""})}} className="crypto-button-blue">
          Start Another Request
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Progress Steps */}
      <div className="flex items-center justify-center mb-12">
        {[1, 2, 3, 4].map((step) => (
          <div key={step} className="flex items-center">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              currentStep >= step ? 'bg-crypto-blue text-white' : 'bg-gray-600 text-gray-400'
            }`}>
              {step}
            </div>
            {step < 4 && (
              <div className={`w-20 h-1 ${
                currentStep > step ? 'bg-crypto-blue' : 'bg-gray-600'
              }`} />
            )}
          </div>
        ))}
      </div>

      {/* Step 1: Service Selection */}
      {currentStep === 1 && (
        <div>
          <h2 className="text-3xl font-bold text-center mb-8">Choose Your Service</h2>
          <div className="grid gap-6">
            {services.map((service) => (
              <Card 
                key={service.id} 
                className={`cursor-pointer transition-all crypto-card ${
                  selectedService === service.id ? 'border-crypto-blue bg-crypto-blue/10' : 'border-gray-700'
                }`}
                onClick={() => setSelectedService(service.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold mb-2">{service.name}</h3>
                      <p className="text-gray-400">{service.description}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-400">Starting from</p>
                      <p className="text-2xl font-bold text-crypto-green">${service.tiers[0].price}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Button 
              onClick={() => setCurrentStep(2)} 
              disabled={!selectedService}
              className="crypto-button-blue"
            >
              Continue <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 2: Tier Selection */}
      {currentStep === 2 && selectedService && (
        <div>
          <h2 className="text-3xl font-bold text-center mb-8">Choose Service Tier</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {services.find(s => s.id === selectedService)?.tiers.map((tier) => (
              <Card 
                key={tier.name}
                className={`cursor-pointer transition-all crypto-card ${
                  selectedTier === tier.name ? 'border-crypto-blue bg-crypto-blue/10' : 'border-gray-700'
                }`}
                onClick={() => setSelectedTier(tier.name)}
              >
                <CardHeader className="text-center">
                  <CardTitle className="text-xl">{tier.name}</CardTitle>
                  <div className="text-3xl font-bold text-crypto-green">${tier.price}</div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {tier.features.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-crypto-green" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="flex justify-center space-x-4 mt-8">
            <Button onClick={() => setCurrentStep(1)} variant="outline">
              Back
            </Button>
            <Button 
              onClick={() => setCurrentStep(3)} 
              disabled={!selectedTier}
              className="crypto-button-blue"
            >
              Continue <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 3: Contact Information */}
      {currentStep === 3 && (
        <div>
          <h2 className="text-3xl font-bold text-center mb-8">Contact Information</h2>
          <Card className="crypto-card max-w-2xl mx-auto">
            <CardContent className="p-8">
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Full Name *</Label>
                    <Input
                      required
                      className="crypto-input mt-2"
                      value={contactData.fullName}
                      onChange={(e) => setContactData(prev => ({ ...prev, fullName: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Phone Number *</Label>
                    <Input
                      type="tel"
                      required
                      className="crypto-input mt-2"
                      value={contactData.phone}
                      onChange={(e) => setContactData(prev => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>
                </div>
                
                <div>
                  <Label className="text-gray-300">Primary Email *</Label>
                  <Input
                    type="email"
                    required
                    className="crypto-input mt-2"
                    value={contactData.email}
                    onChange={(e) => setContactData(prev => ({ ...prev, email: e.target.value }))}
                  />
                </div>

                <div>
                  <Label className="text-gray-300">Preferred Contact Method *</Label>
                  <Select value={contactData.preferredContact} onValueChange={(value) => setContactData(prev => ({ ...prev, preferredContact: value }))}>
                    <SelectTrigger className="crypto-input mt-2">
                      <SelectValue placeholder="Select method..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="phone">Phone</SelectItem>
                      <SelectItem value="whatsapp">WhatsApp</SelectItem>
                      <SelectItem value="telegram">Telegram</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-gray-300">Case Description</Label>
                  <Textarea
                    rows={4}
                    className="crypto-input mt-2"
                    placeholder="Please describe your situation in detail..."
                    value={contactData.description}
                    onChange={(e) => setContactData(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          <div className="flex justify-center space-x-4 mt-8">
            <Button onClick={() => setCurrentStep(2)} variant="outline">
              Back
            </Button>
            <Button 
              onClick={() => setCurrentStep(4)} 
              disabled={!contactData.fullName || !contactData.email || !contactData.phone || !contactData.preferredContact}
              className="crypto-button-blue"
            >
              Continue <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 4: Payment Selection */}
      {currentStep === 4 && (
        <div>
          <h2 className="text-3xl font-bold text-center mb-4">Payment Method</h2>
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 bg-crypto-slate px-4 py-2 rounded-lg">
              <Shield className="h-5 w-5 text-crypto-green" />
              <span className="text-sm">Secure cryptocurrency payments only</span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
            {cryptoPayments.map((crypto, index) => (
              <Card 
                key={index} 
                className={`cursor-pointer transition-all crypto-card ${
                  selectedPayment?.address === crypto.address ? 'border-crypto-blue bg-crypto-blue/10' : 'border-gray-700'
                }`}
                onClick={() => setSelectedPayment(crypto)}
              >
                <CardContent className="p-4">
                  <div className="text-center">
                    <h3 className="font-bold mb-2">{crypto.name}</h3>
                    <p className="text-xs text-gray-400 mb-3">{crypto.network}</p>
                    <div className="bg-crypto-dark p-2 rounded text-xs font-mono break-all">
                      {crypto.address}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {selectedPayment && (
            <Card className="crypto-card max-w-2xl mx-auto mb-8">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4 text-center">Payment Details</h3>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Service:</span>
                    <span className="font-semibold">{getSelectedServiceData().service?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tier:</span>
                    <span className="font-semibold">{selectedTier}</span>
                  </div>
                  <div className="flex justify-between text-lg">
                    <span>Amount:</span>
                    <span className="font-bold text-crypto-green">${getSelectedServiceData().tier?.price}</span>
                  </div>
                  <div className="border-t border-gray-600 pt-4">
                    <div className="flex justify-between items-center mb-2">
                      <span>Pay to:</span>
                      <span className="font-semibold">{selectedPayment.name}</span>
                    </div>
                    <div className="bg-crypto-dark p-3 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-sm break-all">{selectedPayment.address}</span>
                        <div className="flex space-x-2 ml-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyAddress(selectedPayment.address)}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="ghost">
                                <QrCode className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="bg-crypto-dark border-gray-700">
                              <DialogHeader>
                                <DialogTitle className="text-center">{selectedPayment.name} Payment</DialogTitle>
                              </DialogHeader>
                              <div className="text-center p-6">
                                <img
                                  src={generateQRCode(selectedPayment.address)}
                                  alt="QR Code"
                                  className="mx-auto mb-4 rounded-lg"
                                />
                                <p className="text-sm text-gray-400 font-mono break-all">
                                  {selectedPayment.address}
                                </p>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="text-center">
            <p className="text-gray-400 mb-6">
              <CreditCard className="inline mr-2 h-4 w-4" />
              After clicking submit, you'll receive payment confirmation instructions via email
            </p>
            <div className="flex justify-center space-x-4">
              <Button onClick={() => setCurrentStep(3)} variant="outline">
                Back
              </Button>
              <Button 
                onClick={handleSubmitRequest}
                disabled={!selectedPayment || serviceRequestMutation.isPending}
                className="crypto-button-green"
              >
                {serviceRequestMutation.isPending ? "Submitting..." : "Submit Service Request"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}