import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RotateCcw, ArrowRightLeft, Shield, Check } from "lucide-react";

const services = [
  {
    icon: RotateCcw,
    title: "Wallet Recovery",
    description: "Lost access to your wallet? We help recover forgotten passwords, seed phrases, and private keys.",
    price: "From $499",
    color: "crypto-blue",
  },
  {
    icon: ArrowRightLeft,
    title: "Transaction Recovery",
    description: "Recover funds from failed transactions, wrong addresses, or smart contract issues.",
    price: "From $799",
    color: "crypto-green",
  },
  {
    icon: Shield,
    title: "Security Audit",
    description: "Comprehensive security assessment and hardening of your crypto assets and infrastructure.",
    price: "From $1,299",
    color: "crypto-gold",
  },
];

const tiers = [
  {
    name: "Basic",
    color: "crypto-blue",
    features: ["Email Support", "Basic Recovery Tools", "7-day Turnaround"],
  },
  {
    name: "Professional",
    color: "crypto-green",
    features: ["Priority Support", "Advanced Tools", "3-day Turnaround", "Phone Consultation"],
  },
  {
    name: "Enterprise",
    color: "crypto-gold",
    features: ["24/7 Dedicated Support", "Custom Solutions", "Same-day Response", "On-site Support"],
  },
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-crypto-slate">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Our Services</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Choose from our comprehensive range of cryptocurrency recovery and security services
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <Card key={index} className="crypto-card service-card border-gray-700 hover:border-crypto-blue transition-all">
                <CardContent className="p-8 text-center">
                  <div className={`w-16 h-16 bg-${service.color}/20 rounded-full flex items-center justify-center mx-auto mb-6`}>
                    <IconComponent className={`text-${service.color} text-2xl h-8 w-8`} />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
                  <p className="text-gray-400 mb-6">{service.description}</p>
                  <div className="text-3xl font-bold text-crypto-green mb-4">{service.price}</div>
                  <Button className={`w-full crypto-button-${service.color.replace('crypto-', '')}`}>
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Service Tiers */}
        <Card className="crypto-card border-gray-700">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-center mb-8">Service Tiers</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {tiers.map((tier, index) => (
                <div key={index} className={`text-center p-6 border border-gray-600 rounded-lg hover:border-${tier.color}`}>
                  <h4 className={`text-xl font-bold text-${tier.color} mb-4`}>{tier.name}</h4>
                  <ul className="text-gray-400 space-y-2 text-sm">
                    {tier.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center justify-center">
                        <Check className="text-crypto-green mr-2 h-4 w-4" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
