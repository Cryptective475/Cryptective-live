export const sendNotification = async (type: string, data: any) => {
  try {
    // This would integrate with the backend notification system
    console.log(`Notification sent: ${type}`, data);
    
    // In a real implementation, this would call the backend API
    // to send emails to davecarter645@gmail.com
    return true;
  } catch (error) {
    console.error("Failed to send notification:", error);
    return false;
  }
};

export const NOTIFICATION_TYPES = {
  CONTACT_FORM: "contact_form_submitted",
  SERVICE_REQUEST: "service_request_created", 
  USER_REGISTRATION: "user_registered",
  PAYMENT_INITIATED: "payment_initiated",
  RECOVERY_CASE: "recovery_case_submitted",
} as const;

export const getAdminEmail = () => "davecarter645@gmail.com";
export const getSupportEmail = () => "support@cryptective.xyz";
