// Wallet addresses for different cryptocurrencies
export const WALLET_ADDRESSES = {
  BTC: "bc1q64ddhqdhj6k9dsdxzp732vypysnrlqgtxnkz3r",
  ETH: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e",
  USDT_ERC20: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e",
  USDT_TRC20: "TK3VqoZz9ytane8mFQYZY2qkhEXpSFD1N8",
  USDC: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e",
  SOL: "5bNPoCXfv1HjBpd769arF4msVGgxjqEKB18ujZ8eZ1a4",
  BNB: "0x187CF971622C9E47Cb587dbFd310Cc51288E273e",
} as const;

export const generateQRCodeUrl = (address: string, size = 200) => {
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(address)}`;
};

export const copyToClipboard = async (text: string) => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    console.error("Failed to copy to clipboard:", error);
    return false;
  }
};

export const validateCryptoAddress = (address: string, currency: string): boolean => {
  switch (currency.toUpperCase()) {
    case 'BTC':
      // Bitcoin address validation (simplified)
      return /^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,87}$/.test(address);
    case 'ETH':
    case 'USDT':
    case 'USDC':
    case 'BNB':
      // Ethereum address validation
      return /^0x[a-fA-F0-9]{40}$/.test(address);
    case 'SOL':
      // Solana address validation (simplified)
      return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address);
    default:
      return false;
  }
};
