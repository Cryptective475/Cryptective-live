import Layout from "@/components/Layout";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { UserPlus } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Signup() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    firstName: "",
    lastName: "",
    phone: "",
  });

  const signupMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      await apiRequest("POST", "/api/register", data);
    },
    onSuccess: () => {
      toast({
        title: "Account Created",
        description: "Your account has been created successfully! You can now login.",
      });
      setFormData({
        username: "",
        email: "",
        password: "",
        firstName: "",
        lastName: "",
        phone: "",
      });
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: "Please check your information and try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    signupMutation.mutate(formData);
  };

  return (
    <Layout>
      <div className="min-h-screen flex items-center justify-center py-20">
        <Card className="w-full max-w-md crypto-card border-gray-700">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold">Join Cryptective</CardTitle>
            <p className="text-gray-400">Create your crypto recovery account</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">First Name</Label>
                  <Input
                    required
                    className="crypto-input mt-2"
                    value={formData.firstName}
                    onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Last Name</Label>
                  <Input
                    required
                    className="crypto-input mt-2"
                    value={formData.lastName}
                    onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                  />
                </div>
              </div>

              <div>
                <Label className="text-gray-300">Username</Label>
                <Input
                  required
                  className="crypto-input mt-2"
                  value={formData.username}
                  onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                />
              </div>
              
              <div>
                <Label className="text-gray-300">Email Address</Label>
                <Input
                  type="email"
                  required
                  className="crypto-input mt-2"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>

              <div>
                <Label className="text-gray-300">Phone Number</Label>
                <Input
                  type="tel"
                  className="crypto-input mt-2"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                />
              </div>
              
              <div>
                <Label className="text-gray-300">Password</Label>
                <Input
                  type="password"
                  required
                  className="crypto-input mt-2"
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full crypto-button-green"
                disabled={signupMutation.isPending}
              >
                <UserPlus className="mr-2 h-4 w-4" />
                {signupMutation.isPending ? "Creating Account..." : "Create Account"}
              </Button>

              <div className="text-center">
                <p className="text-gray-400">
                  Already have an account?{" "}
                  <Link href="/login">
                    <a className="text-crypto-blue hover:text-blue-400">Login</a>
                  </Link>
                </p>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
