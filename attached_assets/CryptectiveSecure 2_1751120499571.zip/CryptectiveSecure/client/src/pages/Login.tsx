import Layout from "@/components/Layout";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { LogIn } from "lucide-react";

export default function Login() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement login logic
    console.log("Login attempt:", formData);
  };

  return (
    <Layout>
      <div className="min-h-screen flex items-center justify-center py-20">
        <Card className="w-full max-w-md crypto-card border-gray-700">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold">Login to Cryptective</CardTitle>
            <p className="text-gray-400">Access your crypto recovery dashboard</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label className="text-gray-300">Email Address</Label>
                <Input
                  type="email"
                  required
                  className="crypto-input mt-2"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
              
              <div>
                <Label className="text-gray-300">Password</Label>
                <Input
                  type="password"
                  required
                  className="crypto-input mt-2"
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                />
              </div>

              <Button type="submit" className="w-full crypto-button-blue">
                <LogIn className="mr-2 h-4 w-4" />
                Login
              </Button>

              <div className="text-center">
                <p className="text-gray-400">
                  Don't have an account?{" "}
                  <Link href="/signup">
                    <a className="text-crypto-blue hover:text-blue-400">Sign up</a>
                  </Link>
                </p>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
