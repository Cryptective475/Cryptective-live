import Layout from "@/components/Layout";
import ContactSection from "@/components/ContactSection";

export default function Contact() {
  return (
    <Layout>
      <div className="pt-20">
        <div className="container mx-auto px-4 text-center mb-16">
          <h1 className="text-5xl font-bold mb-6">Contact & Support</h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Get in touch with our cryptocurrency recovery experts. We're here to help 24/7.
          </p>
        </div>
        <ContactSection />
      </div>
    </Layout>
  );
}
