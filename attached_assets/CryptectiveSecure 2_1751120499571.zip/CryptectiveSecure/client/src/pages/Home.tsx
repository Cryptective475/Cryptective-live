import Layout from "@/components/Layout";
import LiveStatsWidget from "@/components/LiveStatsWidget";
import HeroSection from "@/components/HeroSection";
import ServicesSection from "@/components/ServicesSection";
import PaymentSection from "@/components/PaymentSection";
import ContactSection from "@/components/ContactSection";
import BlogSection from "@/components/BlogSection";
import FAQSection from "@/components/FAQSection";

export default function Home() {
  return (
    <Layout>
      <LiveStatsWidget />
      <HeroSection />
      <ServicesSection />
      <PaymentSection />
      <ContactSection />
      <BlogSection />
      <FAQSection />
    </Layout>
  );
}
