import Layout from "@/components/Layout";
import FAQSection from "@/components/FAQSection";

export default function FAQ() {
  return (
    <Layout>
      <div className="pt-20">
        <div className="container mx-auto px-4 text-center mb-16">
          <h1 className="text-5xl font-bold mb-6">Frequently Asked Questions</h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Find answers to common questions about our cryptocurrency recovery services
          </p>
        </div>
        <FAQSection />
      </div>
    </Layout>
  );
}
