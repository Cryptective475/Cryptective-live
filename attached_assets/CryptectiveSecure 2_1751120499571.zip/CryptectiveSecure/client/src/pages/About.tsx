import Layout from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Users, Award, Clock } from "lucide-react";

export default function About() {
  return (
    <Layout>
      <div className="pt-20">
        <section className="py-20 bg-crypto-slate">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h1 className="text-5xl font-bold mb-6">About Cryptective</h1>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                Leading the industry in cryptocurrency recovery and blockchain security since 2019
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
              <div>
                <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
                <p className="text-gray-400 mb-6">
                  At Cryptective, we believe that no one should lose their digital assets due to technical failures, 
                  forgotten credentials, or blockchain complexities. Our mission is to provide professional, 
                  reliable cryptocurrency recovery services while maintaining the highest standards of security and confidentiality.
                </p>
                <p className="text-gray-400">
                  Founded by blockchain security experts with over a decade of combined experience, 
                  we've helped thousands of clients recover millions in lost digital assets.
                </p>
              </div>
              <div className="space-y-6">
                <Card className="crypto-card">
                  <CardContent className="p-6 flex items-center space-x-4">
                    <Shield className="text-crypto-blue h-8 w-8" />
                    <div>
                      <h3 className="font-bold">Security First</h3>
                      <p className="text-gray-400 text-sm">End-to-end encryption and secure processes</p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="crypto-card">
                  <CardContent className="p-6 flex items-center space-x-4">
                    <Users className="text-crypto-green h-8 w-8" />
                    <div>
                      <h3 className="font-bold">Expert Team</h3>
                      <p className="text-gray-400 text-sm">Certified blockchain and security specialists</p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="crypto-card">
                  <CardContent className="p-6 flex items-center space-x-4">
                    <Award className="text-crypto-gold h-8 w-8" />
                    <div>
                      <h3 className="font-bold">Proven Results</h3>
                      <p className="text-gray-400 text-sm">98% success rate with $50M+ recovered</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="grid md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold text-crypto-blue mb-2">2019</div>
                <div className="text-gray-400">Founded</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-crypto-green mb-2">5000+</div>
                <div className="text-gray-400">Clients Served</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-crypto-gold mb-2">$50M+</div>
                <div className="text-gray-400">Assets Recovered</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-white mb-2">98%</div>
                <div className="text-gray-400">Success Rate</div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
