import Layout from "@/components/Layout";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

export default function Blog() {
  const { data: posts, isLoading } = useQuery({
    queryKey: ["/api/blog"],
  });

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'security': return 'text-crypto-blue';
      case 'recovery': return 'text-crypto-green';
      case 'market analysis': return 'text-crypto-gold';
      default: return 'text-gray-400';
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="pt-20">
          <section className="py-20 bg-crypto-slate">
            <div className="container mx-auto px-4">
              <div className="text-center mb-16">
                <h1 className="text-5xl font-bold mb-6">Crypto Insights & News</h1>
                <p className="text-xl text-gray-400">Stay updated with the latest cryptocurrency and security news</p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i} className="crypto-card">
                    <Skeleton className="h-48 w-full" />
                    <CardContent className="p-6">
                      <Skeleton className="h-4 w-3/4 mb-2" />
                      <Skeleton className="h-6 w-full mb-3" />
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-2/3" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="pt-20">
        <section className="py-20 bg-crypto-slate">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h1 className="text-5xl font-bold mb-6">Crypto Insights & News</h1>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                Stay updated with the latest cryptocurrency recovery techniques, security tips, and market analysis
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {posts?.map((post) => (
                <Card key={post.id} className="crypto-card border-gray-700 hover:border-crypto-blue transition-all overflow-hidden">
                  <img
                    src={post.imageUrl || "https://images.unsplash.com/photo-1639762681485-074b7f938ba0"}
                    alt={post.title}
                    className="w-full h-48 object-cover"
                  />
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-2 text-sm mb-3">
                      <span className={getCategoryColor(post.category)}>{post.category}</span>
                      <span>•</span>
                      <span className="text-gray-400">
                        {new Date(post.createdAt).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric', 
                          year: 'numeric' 
                        })}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold mb-3">{post.title}</h3>
                    <p className="text-gray-400 mb-4 line-clamp-3">{post.excerpt}</p>
                    <Link href={`/blog/${post.id}`}>
                      <a className={`${getCategoryColor(post.category)} hover:opacity-80 font-semibold`}>
                        Read More →
                      </a>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>

            {(!posts || posts.length === 0) && (
              <div className="text-center py-16">
                <p className="text-gray-400 text-lg">No blog posts available at the moment.</p>
                <p className="text-gray-500 text-sm mt-2">Check back soon for the latest crypto insights!</p>
              </div>
            )}
          </div>
        </section>
      </div>
    </Layout>
  );
}
