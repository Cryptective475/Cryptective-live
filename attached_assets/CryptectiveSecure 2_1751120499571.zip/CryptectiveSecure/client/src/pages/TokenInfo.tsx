import Layout from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";
import LiveStatsWidget from "@/components/LiveStatsWidget";

export default function TokenInfo() {
  return (
    <Layout>
      <LiveStatsWidget />
      <div className="pt-20">
        <section className="py-20 bg-crypto-slate">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h1 className="text-5xl font-bold mb-6">Token Information</h1>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                Live cryptocurrency data and market information for supported tokens
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <Card className="crypto-card">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-6">Supported Cryptocurrencies</h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <i className="fab fa-bitcoin text-crypto-gold text-xl"></i>
                        <span>Bitcoin (BTC)</span>
                      </div>
                      <span className="text-gray-400">Native</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <i className="fab fa-ethereum text-crypto-blue text-xl"></i>
                        <span>Ethereum (ETH)</span>
                      </div>
                      <span className="text-gray-400">ERC-20</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <i className="fas fa-dollar-sign text-crypto-green text-xl"></i>
                        <span>USDT</span>
                      </div>
                      <span className="text-gray-400">ERC-20 / TRC-20</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <i className="fas fa-dollar-sign text-crypto-blue text-xl"></i>
                        <span>USDC</span>
                      </div>
                      <span className="text-gray-400">ERC-20</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <i className="fas fa-coins text-purple-400 text-xl"></i>
                        <span>Solana (SOL)</span>
                      </div>
                      <span className="text-gray-400">Native</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <i className="fas fa-coins text-crypto-gold text-xl"></i>
                        <span>BNB</span>
                      </div>
                      <span className="text-gray-400">BSC</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="crypto-card">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-6">Payment Networks</h2>
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-semibold text-crypto-blue mb-2">Bitcoin Network</h3>
                      <p className="text-gray-400 text-sm">Secure native Bitcoin payments with Bech32 addresses</p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-crypto-green mb-2">Ethereum (ERC-20)</h3>
                      <p className="text-gray-400 text-sm">ETH, USDT, USDC, and other ERC-20 tokens</p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-crypto-gold mb-2">TRON (TRC-20)</h3>
                      <p className="text-gray-400 text-sm">Fast and low-cost USDT transactions</p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-purple-400 mb-2">Solana Network</h3>
                      <p className="text-gray-400 text-sm">High-speed SOL payments with minimal fees</p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-crypto-gold mb-2">Binance Smart Chain</h3>
                      <p className="text-gray-400 text-sm">BNB and BSC-compatible tokens</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="crypto-card">
              <CardContent className="p-8">
                <h2 className="text-2xl font-bold mb-6 text-center">Live Market Data</h2>
                <p className="text-gray-400 text-center mb-8">
                  Real-time cryptocurrency prices powered by CoinGecko API, updated every minute
                </p>
                <div className="text-center">
                  <p className="text-sm text-gray-400">
                    Market data is provided for informational purposes only and should not be considered financial advice.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    </Layout>
  );
}
